<?php

namespace AionChat;

class Response{

    public string $strategy;
    public array $status;
    public string $content;



}
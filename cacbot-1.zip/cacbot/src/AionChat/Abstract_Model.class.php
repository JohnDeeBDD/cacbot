<?php

namespace AionChatMothership;

abstract class Abstract_Model{

        public function send_self_to_model(){}
        public function handle_response(){}
        public function init_this_prompt($comment_id, $status){}

}
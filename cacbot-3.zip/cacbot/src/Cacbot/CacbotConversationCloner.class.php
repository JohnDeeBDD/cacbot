<?php

namespace Cacbot;

class AionConversationCloner{

    public static function do_clone_post($post_id){}

    public static function set_interlocutor($user_id){}

    public static function do_set_first_comment_from_cloned_post($comment_content){}

    public static function do_redirect_user_to_newly_created_cloned_post($post_id){}
}
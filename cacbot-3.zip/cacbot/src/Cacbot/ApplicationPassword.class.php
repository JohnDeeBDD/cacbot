<?php

namespace Cacbot;

class ApplicationPassword{



}
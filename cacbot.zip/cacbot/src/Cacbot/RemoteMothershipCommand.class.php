<?php

namespace Cacbot;

class RemoteMothershipCommand{



}
<?php

namespace Cacbot;

class Response{

    public string $strategy;
    public array $status;
    public string $content;



}
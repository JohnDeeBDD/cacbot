<?php

namespace Cacbot;

/**
 * Class responsible for managing action buttons related to Aion Conversations.
 */
class ActionButtonManager {

    /**
     * Registers the action to add custom buttons to the comment form.
     */
    public static function enable_custom_comment_buttons() {
        \add_action('comment_form', [self::class, 'add_custom_comment_buttons']);
        self::listen_for_button_click();
        \add_filter('comment_form_field_comment', '\Cacbot\ActionButtonManager::add_tool_icons_to_comment_form');
        \add_action('wp_enqueue_scripts', '\Cacbot\ActionButtonManager::enqueue_dashicons');
    }

    /**
     * Outputs custom buttons for the comment form.
     */
    public static function add_custom_comment_buttons() {
        $custom_button_html = '
            <div class="comment-form-custom-buttons">
                <!-- <button type="button" id="cacbot-dall-e-3-button">Fetch Image</button> -->
            </div>';

        echo $custom_button_html;
    }

    public static function listen_for_button_click(){
        if(isset($_GET['cacbot-action'])){

        }
    }

    public static function add_tool_icons_to_comment_form($field) {
        $icons = '<style>
.comment-tool-icons {
    position: relative;
    float:right;
  
    top: 0;
    display: flex;
    flex-direction: column;
    justify-content: start;
}
.comment-tool-icons .dashicons {
    font-size: 24px;
    margin-bottom: 10px;
    cursor: pointer;
}
.comment-form-comment {
    position: relative; /* Ensure the comment box is the reference for the absolute positioning of the icons */
    padding-right: 30px; /* Add padding to prevent the comment box from overlapping with the icons */

}
</style>
<div class="comment-tool-icons">
                <span class="dashicons dashicons-update"></span>
                <span class="dashicons dashicons-image"></span>
                <span class="dashicons dashicons-hammer"></span>
                <span class="dashicons dashicons-visibility"></span>
              </div>';
        return $icons . $field;
    }
    public static function enqueue_dashicons() {
        \wp_enqueue_style('dashicons');
    }
}




